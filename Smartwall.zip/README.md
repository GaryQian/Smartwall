
SmartWall

To run, simply run:

python smartwall.py

Enjoy!